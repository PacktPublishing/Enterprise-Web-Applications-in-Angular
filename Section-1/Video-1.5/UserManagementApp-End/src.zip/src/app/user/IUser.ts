export interface User{
    FName: string,
    LName: string,
    EmpId: number,
    Email: string
}