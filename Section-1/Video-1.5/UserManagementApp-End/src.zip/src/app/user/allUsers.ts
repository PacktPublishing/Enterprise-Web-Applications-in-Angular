import { User } from './IUser';

export const allUsers: User[] = [
    { FName: 'John', LName: 'Smith', EmpId: 10121, 
      Email: 'john.smith@gmail.com' },
    { FName: 'Sam', LName: 'Marker', EmpId: 10122, 
      Email: 'Sam.Marker@gmail.com' },
    { FName: 'Tim', LName: 'Peterson', EmpId: 10123, 
      Email: 'Tim.Peterson@gmail.com' }];